throw new Error(
  'There are no exports in the root module of this package. Import from submodules instead. Use intellisense or the docs to find the available submodules.',
);
